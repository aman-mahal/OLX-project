﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace olx.Models
{
    public class Category
    {
        public int CategoryId { get; set; }

        [Display(Name = "CategoryName")]
        [Required(ErrorMessage = "Category name is required")]
        [MaxLength(45, ErrorMessage = "The category name can be maximum 45 characters long")]
        public string CategoryName { get; set; }

        public string ImageUrl { get; set; }
        public List<Products> Product { get; set; }
    }
}
