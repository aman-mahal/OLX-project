﻿using olx.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OLX_PROJECT.Models
{
    public interface IProductRepository
    {
        IEnumerable<Products> AllProducts { get; }
        //public Products getProductById(int id);
    }
}
