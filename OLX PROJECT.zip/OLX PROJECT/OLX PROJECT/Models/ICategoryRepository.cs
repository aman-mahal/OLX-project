﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using olx.Models;

namespace OLX_PROJECT.Models
{
    public interface ICategoryRepository
    {
        IEnumerable<Category> AllCategories { get; }
    }
}
