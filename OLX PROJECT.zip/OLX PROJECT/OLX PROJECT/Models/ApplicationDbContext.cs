﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace olx.Models
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<User> User { get; set; }

        public DbSet<Products> Products { get; set; }

        public DbSet<Category> Categories { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(" Server = (localdb)\\mssqllocaldb; Database =olxproject; Trusted_Connection = True; MultipleActiveResultSets = true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed categories
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "Car" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "Bike" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 3, CategoryName = "Mobile Phone" });

            //seed products

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 1,
                Name = "mini cooper",
                Price = 1200.95M,
                Description = " well condition car for sale",
                CategoryId = 1,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/red_car_204675.jpg",
                InStock = true,
                ProductLocation="govindpuram"
            });

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 2,
                Name = "royal enfield",
                Price = 120.95M,
                Description = " well condition bike for sale",
                CategoryId = 2,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/2015_bmw_r_ninet_516806.jpg",
                InStock = true,
                ProductLocation = "shashtri nagar"
            });

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 3,
                Name = "iphone 11",
                Price = 10.95M,
                Description = " well condition phone for sale",
                CategoryId = 3,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/phone_vector_275749.jpg",
                InStock = true,
                ProductLocation = "dasna"
            });

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 4,
                Name = "mini cooper",
                Price = 12.95M,
                Description = " well condition car for sale",
                CategoryId = 1,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/red_car_204675.jpg",
                InStock = true,
                ProductLocation = "kavi nagar"
            });

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 5,
                Name = "royal enfield",
                Price = 120.95M,
                Description = " well condition bike for sale",
                CategoryId = 2,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/2015_bmw_r_ninet_516806.jpg",
                InStock = true,
                ProductLocation = "govindpuram"
            });

            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 6,
                Name = "iphone 11",
                Price = 10.95M,
                Description = " well condition phone for sale",
                CategoryId = 3,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/phone_vector_275749.jpg",
                InStock = true,
                ProductLocation = "kavi nagar"
            });
            modelBuilder.Entity<Products>().HasData(new Products
            {
                ProductId = 7,
                Name = "aman cooper",
                Price = 12.95M,
                Description = " well condition car for sale",
                CategoryId = 1,
                ImageUrl = "https://images.all-free-download.com/images/graphicthumb/red_car_204675.jpg",
                InStock = true,
                ProductLocation = "kavi nagar"
            });

        }
    }
}
