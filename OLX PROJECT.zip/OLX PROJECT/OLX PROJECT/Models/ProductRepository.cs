﻿using Microsoft.EntityFrameworkCore;
using olx.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OLX_PROJECT.Models
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public ProductRepository(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public IEnumerable<Products> AllProducts
        {
            get
            {
                return _applicationDbContext.Products;
            }
        }
        //public Products getProductById(int id)
        //{
        //    return AllProducts.FirstOrDefault(p => p.ProductId == id);
        //}
    }
}
