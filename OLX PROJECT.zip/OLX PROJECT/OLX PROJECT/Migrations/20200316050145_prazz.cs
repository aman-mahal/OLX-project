﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace OLX_PROJECT.Migrations
{
    public partial class prazz : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "CategoryId", "Description", "ImageUrl", "InStock", "Name", "Price", "ProductLocation" },
                values: new object[] { 7, 1, " well condition car for sale", "https://images.all-free-download.com/images/graphicthumb/red_car_204675.jpg", true, "aman cooper", 12.95m, "kavi nagar" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 7);
        }
    }
}
