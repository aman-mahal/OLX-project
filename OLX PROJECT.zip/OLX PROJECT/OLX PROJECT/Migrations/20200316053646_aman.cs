﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace OLX_PROJECT.Migrations
{
    public partial class aman : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
