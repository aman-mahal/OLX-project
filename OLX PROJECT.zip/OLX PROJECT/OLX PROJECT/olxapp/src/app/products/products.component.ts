import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { ProductService } from "../services/product.service";
import { Product } from "../models/product";
@Component({
  selector: "app-products",
  templateUrl: "./products.component.html",
  styleUrls: ["./products.component.css"]
})
export class ProductsComponent implements OnInit {
  Products$: Observable<Product[]>;

  constructor(private productService: ProductService) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.Products$ = this.productService.getProducts();
    // console.log(this.productService.getProducts());
  }
}
