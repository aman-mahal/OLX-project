export class Product {
  productId?: number;
  name: string;
  description: string;
  imageUrl: string;
  inStock: string;
  categoryId: number;
  price: number;
  productLocation: string;
}
