export class Category {
  categoryName: string;
  imageUrl: string;
  categoryId: number;
  product: string[];
}
