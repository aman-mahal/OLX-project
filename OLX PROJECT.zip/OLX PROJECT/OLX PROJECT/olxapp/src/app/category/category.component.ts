import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { CategoryService } from "../services/category.service";
import { Category } from "../models/category";

@Component({
  selector: "app-category",
  templateUrl: "./category.component.html",
  styleUrls: ["./category.component.css"]
})
export class CategoryComponent implements OnInit {
  Categories$: Observable<Category[]>;
  constructor(private categoryService: CategoryService) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.Categories$ = this.categoryService.getCategories();
    // console.log(this.productService.getProducts());
  }
}
