import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs";
import { CategoryService } from "../services/category.service";
import { Category } from "../models/category";
@Component({
  selector: "app-categoryproduct",
  templateUrl: "./categoryproduct.component.html",
  styleUrls: ["./categoryproduct.component.css"]
})
export class CategoryproductComponent implements OnInit {
  CategoriesProducts$: Observable<Category>;
  categoryId: number;

  constructor(
    private categoryService: CategoryService,
    private avRoute: ActivatedRoute
  ) {
    const idParam = "id";
    if (this.avRoute.snapshot.params[idParam]) {
      this.categoryId = this.avRoute.snapshot.params[idParam];
    }
  }

  ngOnInit() {
    this.loadCategoriesProducts();
  }
  loadCategoriesProducts() {
    this.CategoriesProducts$ = this.categoryService.getCategory(
      this.categoryId
    );
  }
}
